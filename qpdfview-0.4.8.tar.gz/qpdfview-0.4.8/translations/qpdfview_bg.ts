<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="de_DE">
<context>
    <name>BookmarkMenu</name>
    <message>
        <location filename="../sources/bookmarkmenu.cpp" line="33"/>
        <source>&amp;Open</source>
        <translation type="unfinished">&amp;Отвори</translation>
    </message>
    <message>
        <location filename="../sources/bookmarkmenu.cpp" line="38"/>
        <source>Open in new &amp;tab</source>
        <translation type="unfinished">Отвари в нов &amp;таб</translation>
    </message>
    <message>
        <location filename="../sources/bookmarkmenu.cpp" line="48"/>
        <source>&amp;Remove bookmark</source>
        <translation type="unfinished">&amp;Премахни отметката</translation>
    </message>
</context>
<context>
    <name>Database</name>
    <message>
        <location filename="../sources/database.cpp" line="565"/>
        <source>Jump to page %1</source>
        <translation type="unfinished">Отиди на страница %1</translation>
    </message>
</context>
<context>
    <name>DocumentView</name>
    <message>
        <location filename="../sources/documentview.cpp" line="219"/>
        <source>Supported formats (%1)</source>
        <translation type="unfinished">Поддържани формати (%1)</translation>
    </message>
    <message>
        <location filename="../sources/documentview.cpp" line="437"/>
        <location filename="../sources/documentview.cpp" line="480"/>
        <source>Unlock %1</source>
        <translation type="unfinished">Отключи %1</translation>
    </message>
    <message>
        <location filename="../sources/documentview.cpp" line="437"/>
        <location filename="../sources/documentview.cpp" line="480"/>
        <source>Password:</source>
        <translation type="unfinished">Парола:</translation>
    </message>
    <message>
        <location filename="../sources/documentview.cpp" line="982"/>
        <source>Information</source>
        <translation type="unfinished">Информация</translation>
    </message>
    <message>
        <location filename="../sources/documentview.cpp" line="982"/>
        <source>Opening URL is disabled in the settings.</source>
        <translation type="unfinished">Отварянето на URL е изключено от настройките.</translation>
    </message>
    <message>
        <location filename="../sources/documentview.cpp" line="1032"/>
        <source>Warning</source>
        <translation type="unfinished">Предупреждение</translation>
    </message>
    <message>
        <location filename="../sources/documentview.cpp" line="1032"/>
        <source>SyncTeX data for &apos;%1&apos; could not be found.</source>
        <translation type="unfinished">Не са открити SyncTeX данни за &apos;%1&apos;.</translation>
    </message>
    <message>
        <location filename="../sources/documentview.cpp" line="1440"/>
        <source>Printing &apos;%1&apos;...</source>
        <translation type="unfinished">Принтиране на &apos;%1&apos;...</translation>
    </message>
    <message>
        <location filename="../sources/documentview.cpp" line="1512"/>
        <source>Page %1</source>
        <translation type="unfinished">Страница %1</translation>
    </message>
</context>
<context>
    <name>FileAttachmentAnnotationWidget</name>
    <message>
        <location filename="../sources/annotationwidgets.cpp" line="102"/>
        <source>Save...</source>
        <translation type="unfinished">Съхрани...</translation>
    </message>
    <message>
        <location filename="../sources/annotationwidgets.cpp" line="103"/>
        <source>Save and open...</source>
        <translation type="unfinished">Съхрани и отвори...</translation>
    </message>
    <message>
        <location filename="../sources/annotationwidgets.cpp" line="154"/>
        <source>Save file attachment</source>
        <translation type="unfinished">Съхрани прикачения файл</translation>
    </message>
    <message>
        <location filename="../sources/annotationwidgets.cpp" line="173"/>
        <source>Warning</source>
        <translation type="unfinished">Предупреждение</translation>
    </message>
    <message>
        <location filename="../sources/annotationwidgets.cpp" line="173"/>
        <source>Could not save file attachment to &apos;%1&apos;.</source>
        <translation type="unfinished">Не може да се съхрани прикаченият файл за &apos;%1&apos;.</translation>
    </message>
</context>
<context>
    <name>HelpDialog</name>
    <message>
        <location filename="../sources/helpdialog.cpp" line="40"/>
        <source>help.html</source>
        <extracomment>Please replace by file name of localized help if available, e.g. &quot;help_fr.html&quot;.</extracomment>
        <translation type="unfinished">help.html</translation>
    </message>
    <message>
        <location filename="../sources/helpdialog.cpp" line="54"/>
        <source>Find previous</source>
        <translation type="unfinished">Намери предишния</translation>
    </message>
    <message>
        <location filename="../sources/helpdialog.cpp" line="58"/>
        <source>Find next</source>
        <translation type="unfinished">Намери следващия</translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../sources/mainwindow.cpp" line="168"/>
        <location filename="../sources/mainwindow.cpp" line="237"/>
        <location filename="../sources/mainwindow.cpp" line="938"/>
        <location filename="../sources/mainwindow.cpp" line="955"/>
        <location filename="../sources/mainwindow.cpp" line="972"/>
        <location filename="../sources/mainwindow.cpp" line="1008"/>
        <location filename="../sources/mainwindow.cpp" line="1128"/>
        <location filename="../sources/mainwindow.cpp" line="1750"/>
        <location filename="../sources/mainwindow.cpp" line="1764"/>
        <source>Warning</source>
        <translation type="unfinished">Предупреждение</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="168"/>
        <location filename="../sources/mainwindow.cpp" line="237"/>
        <source>Could not open &apos;%1&apos;.</source>
        <translation type="unfinished">Не може да се отвори &apos;%1&apos;.</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="482"/>
        <source>Close all tabs</source>
        <translation type="unfinished">Затваряне на всички раздели</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="483"/>
        <source>Close all tabs but this one</source>
        <translation type="unfinished">Затваряне на всички раздели, освен този</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="484"/>
        <source>Close all tabs to the left</source>
        <translation type="unfinished">Затвори всички табове на ляво</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="485"/>
        <source>Close all tabs to the right</source>
        <translation type="unfinished">Затвори всички табове на дясно</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="896"/>
        <source>Open</source>
        <translation type="unfinished">Отвoри</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="912"/>
        <source>Open in new tab</source>
        <translation type="unfinished">Отвари в нов таб</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="938"/>
        <location filename="../sources/mainwindow.cpp" line="1128"/>
        <source>Could not refresh &apos;%1&apos;.</source>
        <translation type="unfinished">Не може да се презареди &apos;%1&apos;.</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="945"/>
        <source>Save copy</source>
        <translation type="unfinished">Съхрани копие</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="955"/>
        <source>Could not save copy at &apos;%1&apos;.</source>
        <translation type="unfinished">Не може да се съхрани копие в &apos;%1&apos;.</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="962"/>
        <location filename="../sources/mainwindow.cpp" line="1754"/>
        <source>Save as</source>
        <translation type="unfinished">Съхрани като</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="972"/>
        <location filename="../sources/mainwindow.cpp" line="1764"/>
        <source>Could not save as &apos;%1&apos;.</source>
        <translation type="unfinished">Не може да се съхрани като &apos;%1&apos;.</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1008"/>
        <source>Could not print &apos;%1&apos;.</source>
        <translation type="unfinished">Не може да се отпечати &apos;%1&apos;.</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1044"/>
        <source>Jump to page</source>
        <translation type="unfinished">Отиди на страница</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1044"/>
        <source>Page:</source>
        <translation type="unfinished">Страница:</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1409"/>
        <source>Add bookmark</source>
        <translation type="unfinished">Добави отметка</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1409"/>
        <source>Label</source>
        <translation type="unfinished">Етикет</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1409"/>
        <source>Jump to page %1</source>
        <translation type="unfinished">Отиди на страница %1</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1492"/>
        <source>About qpdfview</source>
        <translation type="unfinished">Относно qpdfview</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1492"/>
        <source>&lt;p&gt;&lt;b&gt;qpdfview %1&lt;/b&gt;&lt;/p&gt;&lt;p&gt;qpdfview is a tabbed document viewer using Qt.&lt;/p&gt;&lt;p&gt;This version includes:&lt;ul&gt;</source>
        <translation type="unfinished">&lt;p&gt;&lt;b&gt;qpdfview %1&lt;/b&gt;&lt;/p&gt;&lt;p&gt;qpdfview e четец на PDF документи, използващ раздели, базиран на Qt.&lt;/p&gt;&lt;p&gt;Тази версия съдържа:&lt;ul&gt;</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1496"/>
        <source>&lt;li&gt;PDF support using Poppler&lt;/li&gt;</source>
        <translation type="unfinished">&lt;li&gt;PDF поддръжка чрез Poppler&lt;/li&gt;</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1499"/>
        <source>&lt;li&gt;PS support using libspectre&lt;/li&gt;</source>
        <translation type="unfinished">&lt;li&gt;PS поддръжка чрез libspectre&lt;/li&gt;</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1502"/>
        <source>&lt;li&gt;DjVu support using DjVuLibre&lt;/li&gt;</source>
        <translation type="unfinished">&lt;li&gt;DjVu поддръжка чрез DjVuLibre&lt;/li&gt;</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1505"/>
        <source>&lt;li&gt;Printing support using CUPS&lt;/li&gt;</source>
        <translation type="unfinished">&lt;li&gt;Поддръжка на отпечатване чрез CUPS&lt;/li&gt;</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1507"/>
        <source>&lt;/ul&gt;&lt;p&gt;See &lt;a href=&quot;https://launchpad.net/qpdfview&quot;&gt;launchpad.net/qpdfview&lt;/a&gt; for more information.&lt;/p&gt;&lt;p&gt;&amp;copy; 2012-2014 The qpdfview developers&lt;/p&gt;</source>
        <translation type="unfinished">&lt;/ul&gt;&lt;p&gt;Вижте &lt;a href=&quot;https://launchpad.net/qpdfview&quot;&gt;launchpad.net/qpdfview&lt;/a&gt; за повече информация.&lt;/p&gt;&lt;p&gt;&amp;copy; 2012-2014 The qpdfview developers&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1750"/>
        <source>The document &apos;%1&apos; has been modified. Do you want to save your changes?</source>
        <translation type="unfinished">Документът &apos;%1&apos; е променен. Искате ли да запазите промените?</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1891"/>
        <source>Page width</source>
        <translation type="unfinished">Ширина на страницата</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1892"/>
        <source>Page size</source>
        <translation type="unfinished">Размер на страницата</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1913"/>
        <source>Match &amp;case</source>
        <translation type="unfinished">Съвпадение на &amp;регистъра</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1914"/>
        <source>Highlight &amp;all</source>
        <translation type="unfinished">Избери &amp;всички</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1958"/>
        <source>&amp;Open...</source>
        <translation type="unfinished">&amp;Отваряне...</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1959"/>
        <source>Open in new &amp;tab...</source>
        <translation type="unfinished">Отваряне в нов &amp;таб...</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1960"/>
        <source>Open containing folder</source>
        <translation type="unfinished">Отвари съдържащата папка</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1961"/>
        <source>&amp;Refresh</source>
        <translation type="unfinished">&amp;Опресняване</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1962"/>
        <source>&amp;Save copy...</source>
        <translation type="unfinished">&amp;Съхрани копие...</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1963"/>
        <source>Save &amp;as...</source>
        <translation type="unfinished">Съхрани &amp;като...</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1964"/>
        <source>&amp;Print...</source>
        <translation type="unfinished">&amp;Принтиране...</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1965"/>
        <source>E&amp;xit</source>
        <translation type="unfinished">&amp;Изход</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1969"/>
        <source>&amp;Previous page</source>
        <translation type="unfinished">&amp;Предишна страница</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1970"/>
        <source>&amp;Next page</source>
        <translation type="unfinished">&amp;Следваща страница</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1971"/>
        <source>&amp;First page</source>
        <translation type="unfinished">&amp;Първа страница</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1972"/>
        <source>&amp;Last page</source>
        <translation type="unfinished">&amp;Последна страница</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1974"/>
        <source>&amp;Jump to page...</source>
        <translation type="unfinished">&amp;Отиди към страница...</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1976"/>
        <source>Jump &amp;backward</source>
        <translation type="unfinished">Отиди на&amp;зад</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1977"/>
        <source>Jump for&amp;ward</source>
        <translation type="unfinished">Отиди на&amp;пред</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1979"/>
        <source>&amp;Search...</source>
        <translation type="unfinished">&amp;Търсене...</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1980"/>
        <source>Find previous</source>
        <translation type="unfinished">Намери предишния</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1981"/>
        <source>Find next</source>
        <translation type="unfinished">Намери следващия</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1982"/>
        <source>Cancel search</source>
        <translation type="unfinished">Отмени търсенето</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1984"/>
        <source>&amp;Copy to clipboard</source>
        <translation type="unfinished">&amp;Копирай в системния буфер</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1985"/>
        <source>&amp;Add annotation</source>
        <translation type="unfinished">&amp;Добави коментар</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1987"/>
        <source>Settings...</source>
        <translation type="unfinished">Настройки...</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1991"/>
        <source>&amp;Continuous</source>
        <translation type="unfinished">Б&amp;ез прекъсване между страниците</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1992"/>
        <source>&amp;Two pages</source>
        <translation type="unfinished">&amp;Две страници</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1993"/>
        <source>Two pages &amp;with cover page</source>
        <translation type="unfinished">Две страници и &amp;обложка</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1994"/>
        <source>&amp;Multiple pages</source>
        <translation type="unfinished">&amp;Множество страници</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1996"/>
        <source>Zoom &amp;in</source>
        <translation type="unfinished">У&amp;величи</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1997"/>
        <source>Zoom &amp;out</source>
        <translation type="unfinished">Н&amp;амали</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1998"/>
        <source>Original &amp;size</source>
        <translation type="unfinished">&amp;Оригинален размер</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="2000"/>
        <source>Fit to page width</source>
        <translation type="unfinished">По ширина</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="2001"/>
        <source>Fit to page size</source>
        <translation type="unfinished">Цялата страница</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="2003"/>
        <source>Rotate &amp;left</source>
        <translation type="unfinished">Завърти на&amp;ляво</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="2004"/>
        <source>Rotate &amp;right</source>
        <translation type="unfinished">Завърти на&amp;дясно</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="2006"/>
        <source>Invert colors</source>
        <translation type="unfinished">Обърни цветовете</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="2008"/>
        <source>Fonts...</source>
        <translation type="unfinished">Шрифтове...</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="2010"/>
        <source>&amp;Fullscreen</source>
        <translation type="unfinished">Цял &amp;екран</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="2011"/>
        <source>&amp;Presentation...</source>
        <translation type="unfinished">&amp;Презентация...</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="2015"/>
        <source>&amp;Previous tab</source>
        <translation type="unfinished">&amp;Предишен таб</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="2016"/>
        <source>&amp;Next tab</source>
        <translation type="unfinished">&amp;Следващ таб</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="2018"/>
        <source>&amp;Close tab</source>
        <translation type="unfinished">&amp;Затвори таба</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="2019"/>
        <source>Close &amp;all tabs</source>
        <translation type="unfinished">Затвори в&amp;сичките табове</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="2020"/>
        <source>Close all tabs &amp;but current tab</source>
        <translation type="unfinished">Затвори всичките табове б&amp;ез настоящия</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="2031"/>
        <source>&amp;Previous bookmark</source>
        <translation type="unfinished">&amp;Предишна отметка</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="2032"/>
        <source>&amp;Next bookmark</source>
        <translation type="unfinished">&amp;Следваща отметка</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="2034"/>
        <source>&amp;Add bookmark</source>
        <translation type="unfinished">&amp;Добави отметка</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="2035"/>
        <source>&amp;Remove bookmark</source>
        <translation type="unfinished">&amp;Премахни отметката</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="2036"/>
        <source>Remove all bookmarks</source>
        <translation type="unfinished">Премахни всички отметки</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="2040"/>
        <source>&amp;Contents</source>
        <translation type="unfinished">&amp;Съдържание</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="2041"/>
        <source>&amp;About</source>
        <translation type="unfinished">&amp;Относно програмата</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="2075"/>
        <location filename="../sources/mainwindow.cpp" line="2202"/>
        <source>&amp;File</source>
        <translation type="unfinished">&amp;Файл</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="2078"/>
        <location filename="../sources/mainwindow.cpp" line="2223"/>
        <source>&amp;Edit</source>
        <translation type="unfinished">&amp;Редактирай</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="2081"/>
        <location filename="../sources/mainwindow.cpp" line="2236"/>
        <source>&amp;View</source>
        <translation type="unfinished">&amp;Преглед</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="2110"/>
        <source>&amp;Outline</source>
        <translation type="unfinished">&amp;Съдържание</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="2123"/>
        <source>&amp;Properties</source>
        <translation type="unfinished">&amp;Свойства</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="2133"/>
        <source>&amp;Thumbnails</source>
        <translation type="unfinished">&amp;Миниатюри</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="2145"/>
        <source>&amp;Search</source>
        <translation type="unfinished">&amp;Търсене</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="2246"/>
        <source>&amp;Tool bars</source>
        <translation type="unfinished">Ленти с &amp;инструменти</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="2249"/>
        <source>&amp;Docks</source>
        <translation type="unfinished">&amp;Панели</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="2258"/>
        <source>&amp;Tabs</source>
        <translation type="unfinished">&amp;Табове</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="2276"/>
        <source>&amp;Bookmarks</source>
        <translation type="unfinished">&amp;Отметки</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="2284"/>
        <source>&amp;Help</source>
        <translation type="unfinished">&amp;Помощ</translation>
    </message>
</context>
<context>
    <name>Model::PdfDocument</name>
    <message>
        <location filename="../sources/pdfmodel.cpp" line="815"/>
        <source>Name</source>
        <translation type="unfinished">Име</translation>
    </message>
    <message>
        <location filename="../sources/pdfmodel.cpp" line="815"/>
        <source>Type</source>
        <translation type="unfinished">Вид</translation>
    </message>
    <message>
        <location filename="../sources/pdfmodel.cpp" line="815"/>
        <source>Embedded</source>
        <translation type="unfinished">Вграден</translation>
    </message>
    <message>
        <location filename="../sources/pdfmodel.cpp" line="815"/>
        <source>Subset</source>
        <translation type="unfinished">Подгрупа</translation>
    </message>
    <message>
        <location filename="../sources/pdfmodel.cpp" line="815"/>
        <source>File</source>
        <translation type="unfinished">Файл</translation>
    </message>
    <message>
        <location filename="../sources/pdfmodel.cpp" line="823"/>
        <location filename="../sources/pdfmodel.cpp" line="824"/>
        <source>Yes</source>
        <translation type="unfinished">Да</translation>
    </message>
    <message>
        <location filename="../sources/pdfmodel.cpp" line="823"/>
        <location filename="../sources/pdfmodel.cpp" line="824"/>
        <source>No</source>
        <translation type="unfinished">Не</translation>
    </message>
</context>
<context>
    <name>Model::PdfPage</name>
    <message>
        <location filename="../sources/pdfmodel.cpp" line="409"/>
        <source>Information</source>
        <translation type="unfinished">Информация</translation>
    </message>
    <message>
        <location filename="../sources/pdfmodel.cpp" line="409"/>
        <source>Version 0.20.1 or higher of the Poppler library is required to add or remove annotations.</source>
        <translation type="unfinished">Нужна е версия 0.20.1 или по-висока на библиотеката Poppler, за да се добавят или премахват анотации.</translation>
    </message>
</context>
<context>
    <name>Model::PsDocument</name>
    <message>
        <location filename="../sources/psmodel.cpp" line="216"/>
        <source>Title</source>
        <translation type="unfinished">Заглавие</translation>
    </message>
    <message>
        <location filename="../sources/psmodel.cpp" line="217"/>
        <source>Created for</source>
        <translation type="unfinished">Създадено за</translation>
    </message>
    <message>
        <location filename="../sources/psmodel.cpp" line="218"/>
        <source>Creator</source>
        <translation type="unfinished">Създател</translation>
    </message>
    <message>
        <location filename="../sources/psmodel.cpp" line="219"/>
        <source>Creation date</source>
        <translation type="unfinished">Дата на създаване</translation>
    </message>
    <message>
        <location filename="../sources/psmodel.cpp" line="220"/>
        <source>Format</source>
        <translation type="unfinished">Формат</translation>
    </message>
    <message>
        <location filename="../sources/psmodel.cpp" line="221"/>
        <source>Language level</source>
        <translation type="unfinished">Ниво на езика</translation>
    </message>
</context>
<context>
    <name>PageItem</name>
    <message>
        <location filename="../sources/pageitem.cpp" line="364"/>
        <source>Go to page %1.</source>
        <translation type="unfinished">Към страница %1.</translation>
    </message>
    <message>
        <location filename="../sources/pageitem.cpp" line="368"/>
        <source>Go to page %1 of file &apos;%2&apos;.</source>
        <translation type="unfinished">Към страница %1 от файла &apos;%2&apos;.</translation>
    </message>
    <message>
        <location filename="../sources/pageitem.cpp" line="376"/>
        <source>Open &apos;%1&apos;.</source>
        <translation type="unfinished">Отвори &apos;%1&apos;.</translation>
    </message>
    <message>
        <location filename="../sources/pageitem.cpp" line="411"/>
        <source>Edit form field &apos;%1&apos;.</source>
        <translation type="unfinished">Редактирай полето на формата &apos;%1&apos;.</translation>
    </message>
    <message>
        <location filename="../sources/pageitem.cpp" line="642"/>
        <source>Copy &amp;text</source>
        <translation type="unfinished">Копирай &amp;текста</translation>
    </message>
    <message>
        <location filename="../sources/pageitem.cpp" line="643"/>
        <source>Copy &amp;image</source>
        <translation type="unfinished">Копирай &amp;снимката</translation>
    </message>
    <message>
        <location filename="../sources/pageitem.cpp" line="644"/>
        <source>Save image to &amp;file...</source>
        <translation type="unfinished">Съхрани снимката във &amp;файл...</translation>
    </message>
    <message>
        <location filename="../sources/pageitem.cpp" line="670"/>
        <source>Save image to file</source>
        <translation type="unfinished">Съхрани снимката във файл</translation>
    </message>
    <message>
        <location filename="../sources/pageitem.cpp" line="674"/>
        <source>Warning</source>
        <translation type="unfinished">Предупреждение</translation>
    </message>
    <message>
        <location filename="../sources/pageitem.cpp" line="674"/>
        <source>Could not save image to file &apos;%1&apos;.</source>
        <translation type="unfinished">Не може да се съхрани снимката във файла &apos;%1&apos;.</translation>
    </message>
    <message>
        <location filename="../sources/pageitem.cpp" line="687"/>
        <source>Add &amp;text</source>
        <translation type="unfinished">Добави &amp;текст</translation>
    </message>
    <message>
        <location filename="../sources/pageitem.cpp" line="688"/>
        <source>Add &amp;highlight</source>
        <translation type="unfinished">Добави п&amp;одчертаване</translation>
    </message>
    <message>
        <location filename="../sources/pageitem.cpp" line="727"/>
        <source>&amp;Remove annotation</source>
        <translation type="unfinished">П&amp;ремахни анотация</translation>
    </message>
</context>
<context>
    <name>PdfSettingsWidget</name>
    <message>
        <location filename="../sources/pdfmodel.cpp" line="839"/>
        <source>Antialiasing:</source>
        <translation type="unfinished">Изглаждане:</translation>
    </message>
    <message>
        <location filename="../sources/pdfmodel.cpp" line="846"/>
        <source>Text antialiasing:</source>
        <translation type="unfinished">Изглаждане на текста:</translation>
    </message>
    <message>
        <location filename="../sources/pdfmodel.cpp" line="853"/>
        <location filename="../sources/pdfmodel.cpp" line="883"/>
        <source>None</source>
        <translation type="unfinished">Без</translation>
    </message>
    <message>
        <location filename="../sources/pdfmodel.cpp" line="854"/>
        <source>Full</source>
        <translation type="unfinished">Пълно</translation>
    </message>
    <message>
        <location filename="../sources/pdfmodel.cpp" line="855"/>
        <source>Reduced</source>
        <translation type="unfinished">Намалено</translation>
    </message>
    <message>
        <location filename="../sources/pdfmodel.cpp" line="858"/>
        <location filename="../sources/pdfmodel.cpp" line="865"/>
        <source>Text hinting:</source>
        <translation type="unfinished">Подсказка за текста:</translation>
    </message>
    <message>
        <location filename="../sources/pdfmodel.cpp" line="876"/>
        <source>Overprint preview:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/pdfmodel.cpp" line="884"/>
        <source>Solid</source>
        <translation type="unfinished">Плътно</translation>
    </message>
    <message>
        <location filename="../sources/pdfmodel.cpp" line="885"/>
        <source>Shaped</source>
        <translation type="unfinished">Оформено</translation>
    </message>
    <message>
        <location filename="../sources/pdfmodel.cpp" line="888"/>
        <source>Thin line mode:</source>
        <translation type="unfinished">Режим на тънката линия:</translation>
    </message>
</context>
<context>
    <name>PluginHandler</name>
    <message>
        <location filename="../sources/pluginhandler.cpp" line="289"/>
        <location filename="../sources/pluginhandler.cpp" line="329"/>
        <location filename="../sources/pluginhandler.cpp" line="370"/>
        <source>Critical</source>
        <translation type="unfinished">Критично</translation>
    </message>
    <message>
        <location filename="../sources/pluginhandler.cpp" line="289"/>
        <source>Could not load PDF plug-in!</source>
        <translation type="unfinished">Не може да се зареди добавката за PDF!</translation>
    </message>
    <message>
        <location filename="../sources/pluginhandler.cpp" line="329"/>
        <source>Could not load PS plug-in!</source>
        <translation type="unfinished">Не може да се зареди добавката за PS!</translation>
    </message>
    <message>
        <location filename="../sources/pluginhandler.cpp" line="370"/>
        <source>Could not load DjVu plug-in!</source>
        <translation type="unfinished">Не може да се зареди добавката за DjVu!</translation>
    </message>
</context>
<context>
    <name>PrintDialog</name>
    <message>
        <location filename="../sources/printdialog.cpp" line="61"/>
        <source>Fit to page:</source>
        <translation type="unfinished">Побири в страницата:</translation>
    </message>
    <message>
        <location filename="../sources/printdialog.cpp" line="65"/>
        <source>Page ranges:</source>
        <translation type="unfinished">Диапазон на страницата:</translation>
    </message>
    <message>
        <location filename="../sources/printdialog.cpp" line="68"/>
        <source>All pages</source>
        <translation type="unfinished">Всички страници</translation>
    </message>
    <message>
        <location filename="../sources/printdialog.cpp" line="69"/>
        <source>Even pages</source>
        <translation type="unfinished">Четните страници</translation>
    </message>
    <message>
        <location filename="../sources/printdialog.cpp" line="70"/>
        <source>Odd pages</source>
        <translation type="unfinished">Нечетните страници</translation>
    </message>
    <message>
        <location filename="../sources/printdialog.cpp" line="73"/>
        <source>Page set:</source>
        <translation type="unfinished">Набор от страници:</translation>
    </message>
    <message>
        <location filename="../sources/printdialog.cpp" line="76"/>
        <source>Single page</source>
        <translation type="unfinished">Една страница</translation>
    </message>
    <message>
        <location filename="../sources/printdialog.cpp" line="77"/>
        <source>Two pages</source>
        <translation type="unfinished">Две страници</translation>
    </message>
    <message>
        <location filename="../sources/printdialog.cpp" line="78"/>
        <source>Four pages</source>
        <translation type="unfinished">Четири страници</translation>
    </message>
    <message>
        <location filename="../sources/printdialog.cpp" line="79"/>
        <source>Six pages</source>
        <translation type="unfinished">Шест страници</translation>
    </message>
    <message>
        <location filename="../sources/printdialog.cpp" line="80"/>
        <source>Nine pages</source>
        <translation type="unfinished">Девет страници</translation>
    </message>
    <message>
        <location filename="../sources/printdialog.cpp" line="81"/>
        <source>Sixteen pages</source>
        <translation type="unfinished">Шестнадесет страници</translation>
    </message>
    <message>
        <location filename="../sources/printdialog.cpp" line="84"/>
        <source>Number-up:</source>
        <translation type="unfinished">Номер нагоре:</translation>
    </message>
    <message>
        <location filename="../sources/printdialog.cpp" line="87"/>
        <source>Bottom to top and left to right</source>
        <translation type="unfinished">Отдолу нагоре и отляво надясно</translation>
    </message>
    <message>
        <location filename="../sources/printdialog.cpp" line="88"/>
        <source>Bottom to top and right to left</source>
        <translation type="unfinished">Отдолу нагоре и отдясно наляво</translation>
    </message>
    <message>
        <location filename="../sources/printdialog.cpp" line="89"/>
        <source>Left to right and bottom to top</source>
        <translation type="unfinished">Отляво на дясно и отдолу нагоре</translation>
    </message>
    <message>
        <location filename="../sources/printdialog.cpp" line="90"/>
        <source>Left to right and top to bottom</source>
        <translation type="unfinished">Отляво надясно и отгоре надолу</translation>
    </message>
    <message>
        <location filename="../sources/printdialog.cpp" line="91"/>
        <source>Right to left and bottom to top</source>
        <translation type="unfinished">Отдясно наляво и отдолу нагоре</translation>
    </message>
    <message>
        <location filename="../sources/printdialog.cpp" line="92"/>
        <source>Right to left and top to bottom</source>
        <translation type="unfinished">Отдясно наляво и отгоре надолу</translation>
    </message>
    <message>
        <location filename="../sources/printdialog.cpp" line="93"/>
        <source>Top to bottom and left to right</source>
        <translation type="unfinished">Отгоре надолу и отляво надясно</translation>
    </message>
    <message>
        <location filename="../sources/printdialog.cpp" line="94"/>
        <source>Top to bottom and right to left</source>
        <translation type="unfinished">Отгоре надолу и от дясно на ляво</translation>
    </message>
    <message>
        <location filename="../sources/printdialog.cpp" line="97"/>
        <source>Number-up layout:</source>
        <translation type="unfinished">Подредба на страниците</translation>
    </message>
    <message>
        <location filename="../sources/printdialog.cpp" line="99"/>
        <source>Extended options</source>
        <translation type="unfinished">Разширени опции</translation>
    </message>
</context>
<context>
    <name>PsSettingsWidget</name>
    <message>
        <location filename="../sources/psmodel.cpp" line="235"/>
        <source>Graphics antialias bits:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/psmodel.cpp" line="243"/>
        <source>Text antialias bits:</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../sources/main.cpp" line="148"/>
        <source>An empty instance name is not allowed.</source>
        <translation type="unfinished">Не е позволено празно име за екземпляра.</translation>
    </message>
    <message>
        <location filename="../sources/main.cpp" line="159"/>
        <source>An empty search text is not allowed.</source>
        <translation type="unfinished">Не е позволен празен текст за търсене.</translation>
    </message>
    <message>
        <location filename="../sources/main.cpp" line="187"/>
        <source>Choose instance</source>
        <translation type="unfinished">Избери инстанция</translation>
    </message>
    <message>
        <location filename="../sources/main.cpp" line="187"/>
        <source>Instance:</source>
        <translation type="unfinished">Инстанция:</translation>
    </message>
    <message>
        <location filename="../sources/main.cpp" line="216"/>
        <source>Unknown command-line option &apos;%1&apos;.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/main.cpp" line="247"/>
        <source>Using &apos;--instance&apos; requires an instance name.</source>
        <translation type="unfinished">Използването на &apos;--instance&apos; изисква име на инстанция.</translation>
    </message>
    <message>
        <location filename="../sources/main.cpp" line="253"/>
        <source>Using &apos;--instance&apos; is not allowed without using &apos;--unique&apos;.</source>
        <translation type="unfinished">Използването на &apos;--instance&apos; не е разрешено без използване на &apos;--unique&apos;.</translation>
    </message>
    <message>
        <location filename="../sources/main.cpp" line="259"/>
        <source>An instance name must only contain the characters &quot;[A-Z][a-z][0-9]_&quot; and must not begin with a digit.</source>
        <translation type="unfinished">Името на инстанцията трябва да съдържа само буквите от &quot;[A-Z][a-z][0-9]_&quot; и не трябва да започва с цифра.</translation>
    </message>
    <message>
        <location filename="../sources/main.cpp" line="265"/>
        <source>Using &apos;--search&apos; requires a search text.</source>
        <translation type="unfinished">Използването на &apos;--search&apos; изисква текст за търсене.</translation>
    </message>
    <message>
        <location filename="../sources/main.cpp" line="343"/>
        <source>SyncTeX data for &apos;%1&apos; could not be found.</source>
        <translation type="unfinished">Не са открити SyncTeX данни за &apos;%1&apos;.</translation>
    </message>
    <message>
        <location filename="../sources/main.cpp" line="440"/>
        <source>Could not prepare signal handler.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QShortcut</name>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="826"/>
        <source>Shift</source>
        <translation type="unfinished">Shift</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="827"/>
        <source>Ctrl</source>
        <translation type="unfinished">Ctrl</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="828"/>
        <source>Alt</source>
        <translation type="unfinished">Alt</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="829"/>
        <source>Shift and Ctrl</source>
        <translation type="unfinished">Shift и Ctrl</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="830"/>
        <source>Shift and Alt</source>
        <translation type="unfinished">Shift и Alt</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="831"/>
        <source>Ctrl and Alt</source>
        <translation type="unfinished">Ctrl и Alt</translation>
    </message>
</context>
<context>
    <name>RecentlyClosedMenu</name>
    <message>
        <location filename="../sources/recentlyclosedmenu.cpp" line="29"/>
        <source>&amp;Recently closed</source>
        <translation type="unfinished">&amp;Наскоро затворени</translation>
    </message>
    <message>
        <location filename="../sources/recentlyclosedmenu.cpp" line="36"/>
        <source>&amp;Clear list</source>
        <translation type="unfinished">&amp;Изчистване на списък</translation>
    </message>
</context>
<context>
    <name>RecentlyUsedMenu</name>
    <message>
        <location filename="../sources/recentlyusedmenu.cpp" line="29"/>
        <source>Recently &amp;used</source>
        <translation type="unfinished">Последно &amp;използвани</translation>
    </message>
    <message>
        <location filename="../sources/recentlyusedmenu.cpp" line="38"/>
        <source>&amp;Clear list</source>
        <translation type="unfinished">&amp;Изчисти списъка</translation>
    </message>
</context>
<context>
    <name>SettingsDialog</name>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="74"/>
        <source>General</source>
        <translation type="unfinished">Основни</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="125"/>
        <source>&amp;Behavior</source>
        <translation type="unfinished">Пов&amp;едение</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="126"/>
        <source>&amp;Graphics</source>
        <translation type="unfinished">&amp;Графика</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="127"/>
        <source>&amp;Interface</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="128"/>
        <source>&amp;Shortcuts</source>
        <translation type="unfinished">Б&amp;ързи клавиши</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="129"/>
        <source>&amp;Modifiers</source>
        <translation type="unfinished">&amp;Модификатори</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="135"/>
        <source>Defaults</source>
        <translation type="unfinished">Стандартни</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="138"/>
        <source>Defaults on current tab</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="231"/>
        <source>Open URL:</source>
        <translation type="unfinished">Отвори URL:</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="238"/>
        <source>Auto-refresh:</source>
        <translation type="unfinished">Автоматично опресняване:</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="244"/>
        <location filename="../sources/settingsdialog.cpp" line="252"/>
        <location filename="../sources/settingsdialog.cpp" line="622"/>
        <location filename="../sources/settingsdialog.cpp" line="631"/>
        <location filename="../sources/settingsdialog.cpp" line="639"/>
        <location filename="../sources/settingsdialog.cpp" line="647"/>
        <location filename="../sources/settingsdialog.cpp" line="655"/>
        <source>Effective after restart.</source>
        <translation type="unfinished">Ефективно след рестартиране.</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="246"/>
        <source>Track recently used:</source>
        <translation type="unfinished">Проследи последно използваните:</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="254"/>
        <source>Keep recently closed:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="261"/>
        <source>Restore tabs:</source>
        <translation type="unfinished">Възстанови табове:</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="268"/>
        <source>Restore bookmarks:</source>
        <translation type="unfinished">Възстанови отметки:</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="275"/>
        <source>Restore per-file settings:</source>
        <translation type="unfinished">Възстановяване на настройки според файл:</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="290"/>
        <source>Synchronize presentation:</source>
        <translation type="unfinished">Синхронизация на презентация:</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="296"/>
        <source>Default</source>
        <translation type="unfinished">По подразбиране</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="299"/>
        <source>Presentation screen:</source>
        <translation type="unfinished">Екран за презентации:</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="307"/>
        <source>None</source>
        <translation type="unfinished">Няма</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="310"/>
        <source>Highlight duration:</source>
        <translation type="unfinished">Продължителност на осветяването:</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="316"/>
        <source>Highlight color:</source>
        <translation type="unfinished">Цвят за маркиране:</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="322"/>
        <source>Annotation color:</source>
        <translation type="unfinished">Цвят за анотацията:</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="328"/>
        <source>&apos;%1&apos; is replaced by the absolute file path. &apos;%2&apos; resp. &apos;%3&apos; is replaced by line resp. column number.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="330"/>
        <source>Source editor:</source>
        <translation type="unfinished">Редактор на източник:</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="386"/>
        <source>Keep obsolete pixmaps:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="395"/>
        <source>Use device pixel ratio:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="404"/>
        <source>Decorate pages:</source>
        <translation type="unfinished">Рамка на страниците:</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="411"/>
        <source>Decorate links:</source>
        <translation type="unfinished">Маркиране на линкове:</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="418"/>
        <source>Decorate form fields:</source>
        <translation type="unfinished">Маркиране на формулярни полета:</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="424"/>
        <source>Background color:</source>
        <translation type="unfinished">Цвят на фона:</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="430"/>
        <source>Paper color:</source>
        <translation type="unfinished">Цвят на хартията:</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="436"/>
        <source>Presentation background color:</source>
        <translation type="unfinished">Цвят на фона за презентация:</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="444"/>
        <source>Pages per row:</source>
        <translation type="unfinished">Страници в един ред:</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="454"/>
        <source>Page spacing:</source>
        <translation type="unfinished">Разстояние между страниците:</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="464"/>
        <source>Thumbnail spacing:</source>
        <translation type="unfinished">Разстояние между миниатюрите:</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="474"/>
        <source>Thumbnail size:</source>
        <translation type="unfinished">Размер на миниатюрите:</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="479"/>
        <location filename="../sources/settingsdialog.cpp" line="480"/>
        <location filename="../sources/settingsdialog.cpp" line="481"/>
        <location filename="../sources/settingsdialog.cpp" line="482"/>
        <location filename="../sources/settingsdialog.cpp" line="483"/>
        <location filename="../sources/settingsdialog.cpp" line="484"/>
        <location filename="../sources/settingsdialog.cpp" line="485"/>
        <location filename="../sources/settingsdialog.cpp" line="486"/>
        <location filename="../sources/settingsdialog.cpp" line="487"/>
        <location filename="../sources/settingsdialog.cpp" line="488"/>
        <source>%1 MB</source>
        <translation type="unfinished">%1 Mб</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="491"/>
        <source>Cache size:</source>
        <translation type="unfinished">Размер на кеша:</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="498"/>
        <source>Prefetch:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="506"/>
        <source>Prefetch distance:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="592"/>
        <source>Top</source>
        <translation type="unfinished">Отгоре</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="593"/>
        <source>Bottom</source>
        <translation type="unfinished">Отдолу</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="594"/>
        <source>Left</source>
        <translation type="unfinished">Отляво</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="595"/>
        <source>Right</source>
        <translation type="unfinished">Отдясно</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="598"/>
        <source>Tab position:</source>
        <translation type="unfinished">Разположение на табовете:</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="603"/>
        <source>As needed</source>
        <translation type="unfinished">При необходимост</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="604"/>
        <source>Always</source>
        <translation type="unfinished">Винаги</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="605"/>
        <source>Never</source>
        <translation type="unfinished">Никога</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="608"/>
        <source>Tab visibility:</source>
        <translation type="unfinished">Видимост на табовете:</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="615"/>
        <source>New tab next to current tab:</source>
        <translation type="unfinished">Новият таб в непосредствена близост до сегашният таб:</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="624"/>
        <source>Recently used count:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="633"/>
        <source>Recently closed count:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="641"/>
        <source>File tool bar:</source>
        <translation type="unfinished">Файлов панел:</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="649"/>
        <source>Edit tool bar:</source>
        <translation type="unfinished">Панел за редактиране:</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="657"/>
        <source>View tool bar:</source>
        <translation type="unfinished">Панел за преглед:</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="664"/>
        <source>Current page in window title:</source>
        <translation type="unfinished">Текуща страница в заглавието на прозореца:</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="671"/>
        <source>Instance name in window title:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="678"/>
        <source>Synchronize outline view:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="685"/>
        <source>Highlight current thumbnail:</source>
        <translation type="unfinished">Маркиране на текущата миниатюра:</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="692"/>
        <source>Limit thumbnails to results:</source>
        <translation type="unfinished">Лимит на миниатюри е резултатите:</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="699"/>
        <source>Annotation overlay:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="706"/>
        <source>Form field overlay:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="766"/>
        <source>Zoom:</source>
        <translation type="unfinished">Увеличаване:</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="772"/>
        <source>Rotate:</source>
        <translation type="unfinished">Завъртане:</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="778"/>
        <source>Scroll:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="784"/>
        <source>Copy to clipboard:</source>
        <translation type="unfinished">Копирай в клипборда:</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="790"/>
        <source>Add annotation:</source>
        <translation type="unfinished">Добави анотация:</translation>
    </message>
</context>
<context>
    <name>ShortcutHandler</name>
    <message>
        <location filename="../sources/shortcuthandler.cpp" line="140"/>
        <source>Action</source>
        <translation type="unfinished">Действиe</translation>
    </message>
    <message>
        <location filename="../sources/shortcuthandler.cpp" line="143"/>
        <source>Key sequence</source>
        <translation type="unfinished">Последователност на клавишите</translation>
    </message>
    <message>
        <location filename="../sources/shortcuthandler.cpp" line="261"/>
        <source>Skip backward</source>
        <translation type="unfinished">Пропусни назад</translation>
    </message>
    <message>
        <location filename="../sources/shortcuthandler.cpp" line="268"/>
        <source>Skip forward</source>
        <translation type="unfinished">Пропусни напред</translation>
    </message>
    <message>
        <location filename="../sources/shortcuthandler.cpp" line="275"/>
        <source>Move up</source>
        <translation type="unfinished">Премести нагоре</translation>
    </message>
    <message>
        <location filename="../sources/shortcuthandler.cpp" line="282"/>
        <source>Move down</source>
        <translation type="unfinished">Премести надолу</translation>
    </message>
    <message>
        <location filename="../sources/shortcuthandler.cpp" line="289"/>
        <source>Move left</source>
        <translation type="unfinished">Премести наляво</translation>
    </message>
    <message>
        <location filename="../sources/shortcuthandler.cpp" line="296"/>
        <source>Move right</source>
        <translation type="unfinished">Премести надясно</translation>
    </message>
</context>
<context>
    <name>TreeView</name>
    <message>
        <location filename="../sources/miscellaneous.cpp" line="190"/>
        <source>&amp;Expand all</source>
        <translation type="unfinished">&amp;Разгъни всички</translation>
    </message>
    <message>
        <location filename="../sources/miscellaneous.cpp" line="191"/>
        <source>&amp;Collapse all</source>
        <translation type="unfinished">&amp;Сгъни всички</translation>
    </message>
</context>
</TS>
