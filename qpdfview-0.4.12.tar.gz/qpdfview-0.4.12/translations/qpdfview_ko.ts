<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0">
    <extra-po-header-po_revision_date>2013-11-19 10:28+0000</extra-po-header-po_revision_date>
    <extra-po-header-x_launchpad_export_date>2013-11-20 05:40+0000</extra-po-header-x_launchpad_export_date>
    <extra-po-headers>Project-Id-Version,Report-Msgid-Bugs-To,POT-Creation-Date,PO-Revision-Date,Last-Translator,Language-Team,MIME-Version,Content-Type,Content-Transfer-Encoding,X-Launchpad-Export-Date,X-Generator</extra-po-headers>
    <extra-po-header-x_generator>Launchpad (build 16831)</extra-po-header-x_generator>
    <extra-po-header-report_msgid_bugs_to>FULL NAME &lt;EMAIL@ADDRESS&gt;</extra-po-header-report_msgid_bugs_to>
    <extra-po-header-language_team>Korean &lt;ko@li.org&gt;</extra-po-header-language_team>
    <extra-po-header-project_id_version>qpdfview</extra-po-header-project_id_version>
    <extra-po-header-pot_creation_date>2013-11-06 17:31+0000</extra-po-header-pot_creation_date>
    <extra-po-header_comment># Korean translation for qpdfview
# Copyright (c) 2013 Rosetta Contributors and Canonical Ltd 2013
# This file is distributed under the same license as the qpdfview package.
# FIRST AUTHOR &lt;EMAIL@ADDRESS&gt;, 2013.
#</extra-po-header_comment>
    <extra-po-header-last_translator>Litty &lt;Unknown&gt;</extra-po-header-last_translator>
<context>
    <name></name>
    <message>
        <location filename="../sources/bookmarkmenu.cpp" line="35"/>
        <source>&amp;Open</source>
        <comment>BookmarkMenu|</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/bookmarkmenu.cpp" line="40"/>
        <source>Open in new &amp;tab</source>
        <comment>BookmarkMenu|</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/bookmarkmenu.cpp" line="50"/>
        <source>&amp;Remove bookmark</source>
        <comment>BookmarkMenu|</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/database.cpp" line="560"/>
        <source>Jump to page %1</source>
        <comment>Database|</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/documentview.cpp" line="227"/>
        <source>Supported formats (%1)</source>
        <comment>DocumentView|</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/documentview.cpp" line="498"/>
        <location filename="../sources/documentview.cpp" line="542"/>
        <source>Unlock %1</source>
        <comment>DocumentView|</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/documentview.cpp" line="498"/>
        <location filename="../sources/documentview.cpp" line="542"/>
        <source>Password:</source>
        <comment>DocumentView|</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/documentview.cpp" line="1045"/>
        <source>Information</source>
        <comment>DocumentView|</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/documentview.cpp" line="1045"/>
        <source>Opening URL is disabled in the settings.</source>
        <comment>DocumentView|</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/documentview.cpp" line="1097"/>
        <source>Warning</source>
        <comment>DocumentView|</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/documentview.cpp" line="1097"/>
        <source>SyncTeX data for &apos;%1&apos; could not be found.</source>
        <comment>DocumentView|</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/documentview.cpp" line="1501"/>
        <source>Printing &apos;%1&apos;...</source>
        <comment>DocumentView|</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/documentview.cpp" line="1578"/>
        <source>Page %1</source>
        <comment>DocumentView|</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/annotationwidgets.cpp" line="102"/>
        <source>Save...</source>
        <comment>FileAttachmentAnnotationWidget|</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/annotationwidgets.cpp" line="103"/>
        <source>Save and open...</source>
        <comment>FileAttachmentAnnotationWidget|</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/annotationwidgets.cpp" line="154"/>
        <source>Save file attachment</source>
        <comment>FileAttachmentAnnotationWidget|</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/annotationwidgets.cpp" line="173"/>
        <source>Warning</source>
        <comment>FileAttachmentAnnotationWidget|</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/annotationwidgets.cpp" line="173"/>
        <source>Could not save file attachment to &apos;%1&apos;.</source>
        <comment>FileAttachmentAnnotationWidget|</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/helpdialog.cpp" line="40"/>
        <source>help.html</source>
        <comment>HelpDialog|</comment>
        <extracomment>Please replace by file name of localized help if available, e.g. &quot;help_fr.html&quot;.
</extracomment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/helpdialog.cpp" line="54"/>
        <source>Find previous</source>
        <comment>HelpDialog|</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/helpdialog.cpp" line="58"/>
        <source>Find next</source>
        <comment>HelpDialog|</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="170"/>
        <location filename="../sources/mainwindow.cpp" line="263"/>
        <location filename="../sources/mainwindow.cpp" line="980"/>
        <location filename="../sources/mainwindow.cpp" line="998"/>
        <location filename="../sources/mainwindow.cpp" line="1015"/>
        <location filename="../sources/mainwindow.cpp" line="1051"/>
        <location filename="../sources/mainwindow.cpp" line="1174"/>
        <location filename="../sources/mainwindow.cpp" line="1859"/>
        <location filename="../sources/mainwindow.cpp" line="1873"/>
        <source>Warning</source>
        <comment>MainWindow|</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="170"/>
        <location filename="../sources/mainwindow.cpp" line="263"/>
        <source>Could not open &apos;%1&apos;.</source>
        <comment>MainWindow|</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="508"/>
        <source>Close all tabs but this one</source>
        <comment>MainWindow|</comment>
        <translation>이 탭만 남기고 모두 닫기</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="509"/>
        <source>Close all tabs to the left</source>
        <comment>MainWindow|</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="510"/>
        <source>Close all tabs to the right</source>
        <comment>MainWindow|</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="936"/>
        <source>Open</source>
        <comment>MainWindow|</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="952"/>
        <source>Open in new tab</source>
        <comment>MainWindow|</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="980"/>
        <location filename="../sources/mainwindow.cpp" line="1174"/>
        <source>Could not refresh &apos;%1&apos;.</source>
        <comment>MainWindow|</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="988"/>
        <source>Save copy</source>
        <comment>MainWindow|</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="998"/>
        <source>Could not save copy at &apos;%1&apos;.</source>
        <comment>MainWindow|</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1005"/>
        <location filename="../sources/mainwindow.cpp" line="1863"/>
        <source>Save as</source>
        <comment>MainWindow|</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1015"/>
        <location filename="../sources/mainwindow.cpp" line="1873"/>
        <source>Could not save as &apos;%1&apos;.</source>
        <comment>MainWindow|</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1051"/>
        <source>Could not print &apos;%1&apos;.</source>
        <comment>MainWindow|</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1090"/>
        <source>Jump to page</source>
        <comment>MainWindow|</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1090"/>
        <source>Page:</source>
        <comment>MainWindow|</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1480"/>
        <source>Add bookmark</source>
        <comment>MainWindow|</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1480"/>
        <source>Label</source>
        <comment>MainWindow|</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1480"/>
        <source>Jump to page %1</source>
        <comment>MainWindow|</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1563"/>
        <source>About qpdfview</source>
        <comment>MainWindow|</comment>
        <translation>gpdfview에 대하여</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1563"/>
        <source>&lt;p&gt;&lt;b&gt;qpdfview %1&lt;/b&gt;&lt;/p&gt;&lt;p&gt;qpdfview is a tabbed document viewer using Qt.&lt;/p&gt;&lt;p&gt;This version includes:&lt;ul&gt;</source>
        <comment>MainWindow|</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1567"/>
        <source>&lt;li&gt;PDF support using Poppler&lt;/li&gt;</source>
        <comment>MainWindow|</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1570"/>
        <source>&lt;li&gt;PS support using libspectre&lt;/li&gt;</source>
        <comment>MainWindow|</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1573"/>
        <source>&lt;li&gt;DjVu support using DjVuLibre&lt;/li&gt;</source>
        <comment>MainWindow|</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1576"/>
        <source>&lt;li&gt;Printing support using CUPS&lt;/li&gt;</source>
        <comment>MainWindow|</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1578"/>
        <source>&lt;/ul&gt;&lt;p&gt;See &lt;a href=&quot;https://launchpad.net/qpdfview&quot;&gt;launchpad.net/qpdfview&lt;/a&gt; for more information.&lt;/p&gt;&lt;p&gt;&amp;copy; 2012-2013 The qpdfview developers&lt;/p&gt;</source>
        <comment>MainWindow|</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1859"/>
        <source>The document &apos;%1&apos; has been modified. Do you want to save your changes?</source>
        <comment>MainWindow|</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1929"/>
        <source>Page width</source>
        <comment>MainWindow|</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1930"/>
        <source>Page size</source>
        <comment>MainWindow|</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1951"/>
        <source>Match &amp;case</source>
        <comment>MainWindow|</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1952"/>
        <source>Highlight &amp;all</source>
        <comment>MainWindow|</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1996"/>
        <source>&amp;Open...</source>
        <comment>MainWindow|</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1997"/>
        <source>Open in new &amp;tab...</source>
        <comment>MainWindow|</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1998"/>
        <source>Open containing folder</source>
        <comment>MainWindow|</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1999"/>
        <source>&amp;Refresh</source>
        <comment>MainWindow|</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="2000"/>
        <source>&amp;Save copy...</source>
        <comment>MainWindow|</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="2001"/>
        <source>Save &amp;as...</source>
        <comment>MainWindow|</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="2002"/>
        <source>&amp;Print...</source>
        <comment>MainWindow|</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="2003"/>
        <source>E&amp;xit</source>
        <comment>MainWindow|</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="2007"/>
        <source>&amp;Previous page</source>
        <comment>MainWindow|</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="2008"/>
        <source>&amp;Next page</source>
        <comment>MainWindow|</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="2009"/>
        <source>&amp;First page</source>
        <comment>MainWindow|</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="2010"/>
        <source>&amp;Last page</source>
        <comment>MainWindow|</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="2012"/>
        <source>&amp;Jump to page...</source>
        <comment>MainWindow|</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="2014"/>
        <source>Jump &amp;backward</source>
        <comment>MainWindow|</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="2015"/>
        <source>Jump for&amp;ward</source>
        <comment>MainWindow|</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="2017"/>
        <source>&amp;Search...</source>
        <comment>MainWindow|</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="2018"/>
        <source>Find previous</source>
        <comment>MainWindow|</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="2019"/>
        <source>Find next</source>
        <comment>MainWindow|</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="2020"/>
        <source>Cancel search</source>
        <comment>MainWindow|</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="2022"/>
        <source>&amp;Copy to clipboard</source>
        <comment>MainWindow|</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="2023"/>
        <source>&amp;Add annotation</source>
        <comment>MainWindow|</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="2025"/>
        <source>Settings...</source>
        <comment>MainWindow|</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="2029"/>
        <source>&amp;Continuous</source>
        <comment>MainWindow|</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="2030"/>
        <source>&amp;Two pages</source>
        <comment>MainWindow|</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="2031"/>
        <source>Two pages &amp;with cover page</source>
        <comment>MainWindow|</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="2032"/>
        <source>&amp;Multiple pages</source>
        <comment>MainWindow|</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="2034"/>
        <source>Zoom &amp;in</source>
        <comment>MainWindow|</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="2035"/>
        <source>Zoom &amp;out</source>
        <comment>MainWindow|</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="2036"/>
        <source>Original &amp;size</source>
        <comment>MainWindow|</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="2038"/>
        <source>Fit to page width</source>
        <comment>MainWindow|</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="2039"/>
        <source>Fit to page size</source>
        <comment>MainWindow|</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="2041"/>
        <source>Rotate &amp;left</source>
        <comment>MainWindow|</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="2042"/>
        <source>Rotate &amp;right</source>
        <comment>MainWindow|</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="2044"/>
        <source>Invert colors</source>
        <comment>MainWindow|</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="2046"/>
        <source>Fonts...</source>
        <comment>MainWindow|</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="2048"/>
        <source>&amp;Fullscreen</source>
        <comment>MainWindow|</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="2049"/>
        <source>&amp;Presentation...</source>
        <comment>MainWindow|</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="2053"/>
        <source>&amp;Previous tab</source>
        <comment>MainWindow|</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="2054"/>
        <source>&amp;Next tab</source>
        <comment>MainWindow|</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="2056"/>
        <source>&amp;Close tab</source>
        <comment>MainWindow|</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="2057"/>
        <source>Close &amp;all tabs</source>
        <comment>MainWindow|</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="2058"/>
        <source>Close all tabs &amp;but current tab</source>
        <comment>MainWindow|</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="2069"/>
        <source>&amp;Previous bookmark</source>
        <comment>MainWindow|</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="2070"/>
        <source>&amp;Next bookmark</source>
        <comment>MainWindow|</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="2072"/>
        <source>&amp;Add bookmark</source>
        <comment>MainWindow|</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="2073"/>
        <source>&amp;Remove bookmark</source>
        <comment>MainWindow|</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="2074"/>
        <source>Remove all bookmarks</source>
        <comment>MainWindow|</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="2078"/>
        <source>&amp;Contents</source>
        <comment>MainWindow|</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="2079"/>
        <source>&amp;About</source>
        <comment>MainWindow|</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="2113"/>
        <location filename="../sources/mainwindow.cpp" line="2230"/>
        <source>&amp;File</source>
        <comment>MainWindow|</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="2116"/>
        <location filename="../sources/mainwindow.cpp" line="2265"/>
        <source>&amp;Edit</source>
        <comment>MainWindow|</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="2119"/>
        <location filename="../sources/mainwindow.cpp" line="2278"/>
        <source>&amp;View</source>
        <comment>MainWindow|</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="2148"/>
        <source>&amp;Outline</source>
        <comment>MainWindow|</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="2161"/>
        <source>&amp;Properties</source>
        <comment>MainWindow|</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="2171"/>
        <source>&amp;Thumbnails</source>
        <comment>MainWindow|</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="2183"/>
        <source>&amp;Search</source>
        <comment>MainWindow|</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="2288"/>
        <source>&amp;Tool bars</source>
        <comment>MainWindow|</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="2291"/>
        <source>&amp;Docks</source>
        <comment>MainWindow|</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="2300"/>
        <source>&amp;Tabs</source>
        <comment>MainWindow|</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="2308"/>
        <source>&amp;Bookmarks</source>
        <comment>MainWindow|</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="2316"/>
        <source>&amp;Help</source>
        <comment>MainWindow|</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/pdfmodel.cpp" line="818"/>
        <source>Name</source>
        <comment>Model::PdfDocument|</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/pdfmodel.cpp" line="818"/>
        <source>Type</source>
        <comment>Model::PdfDocument|</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/pdfmodel.cpp" line="818"/>
        <source>Embedded</source>
        <comment>Model::PdfDocument|</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/pdfmodel.cpp" line="818"/>
        <source>Subset</source>
        <comment>Model::PdfDocument|</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/pdfmodel.cpp" line="818"/>
        <source>File</source>
        <comment>Model::PdfDocument|</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/pdfmodel.cpp" line="826"/>
        <location filename="../sources/pdfmodel.cpp" line="827"/>
        <source>Yes</source>
        <comment>Model::PdfDocument|</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/pdfmodel.cpp" line="826"/>
        <location filename="../sources/pdfmodel.cpp" line="827"/>
        <source>No</source>
        <comment>Model::PdfDocument|</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/pdfmodel.cpp" line="412"/>
        <source>Information</source>
        <comment>Model::PdfPage|</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/pdfmodel.cpp" line="412"/>
        <source>Version 0.20.1 or higher of the Poppler library is required to add or remove annotations.</source>
        <comment>Model::PdfPage|</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/psmodel.cpp" line="217"/>
        <source>Title</source>
        <comment>Model::PsDocument|</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/psmodel.cpp" line="218"/>
        <source>Created for</source>
        <comment>Model::PsDocument|</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/psmodel.cpp" line="219"/>
        <source>Creator</source>
        <comment>Model::PsDocument|</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/psmodel.cpp" line="220"/>
        <source>Creation date</source>
        <comment>Model::PsDocument|</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/psmodel.cpp" line="221"/>
        <source>Format</source>
        <comment>Model::PsDocument|</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/psmodel.cpp" line="222"/>
        <source>Language level</source>
        <comment>Model::PsDocument|</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/pageitem.cpp" line="434"/>
        <source>Go to page %1.</source>
        <comment>PageItem|</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/pageitem.cpp" line="438"/>
        <source>Go to page %1 of file &apos;%2&apos;.</source>
        <comment>PageItem|</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/pageitem.cpp" line="446"/>
        <source>Open &apos;%1&apos;.</source>
        <comment>PageItem|</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/pageitem.cpp" line="481"/>
        <source>Edit form field &apos;%1&apos;.</source>
        <comment>PageItem|</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/pageitem.cpp" line="712"/>
        <source>Copy &amp;text</source>
        <comment>PageItem|</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/pageitem.cpp" line="713"/>
        <source>Copy &amp;image</source>
        <comment>PageItem|</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/pageitem.cpp" line="714"/>
        <source>Save image to &amp;file...</source>
        <comment>PageItem|</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/pageitem.cpp" line="740"/>
        <source>Save image to file</source>
        <comment>PageItem|</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/pageitem.cpp" line="744"/>
        <source>Warning</source>
        <comment>PageItem|</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/pageitem.cpp" line="744"/>
        <source>Could not save image to file &apos;%1&apos;.</source>
        <comment>PageItem|</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/pageitem.cpp" line="757"/>
        <source>Add &amp;text</source>
        <comment>PageItem|</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/pageitem.cpp" line="758"/>
        <source>Add &amp;highlight</source>
        <comment>PageItem|</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/pageitem.cpp" line="797"/>
        <source>&amp;Remove annotation</source>
        <comment>PageItem|</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/pdfmodel.cpp" line="842"/>
        <source>Antialiasing:</source>
        <comment>PdfSettingsWidget|</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/pdfmodel.cpp" line="849"/>
        <source>Text antialiasing:</source>
        <comment>PdfSettingsWidget|</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/pdfmodel.cpp" line="856"/>
        <location filename="../sources/pdfmodel.cpp" line="886"/>
        <source>None</source>
        <comment>PdfSettingsWidget|</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/pdfmodel.cpp" line="857"/>
        <source>Full</source>
        <comment>PdfSettingsWidget|</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/pdfmodel.cpp" line="858"/>
        <source>Reduced</source>
        <comment>PdfSettingsWidget|</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/pdfmodel.cpp" line="861"/>
        <location filename="../sources/pdfmodel.cpp" line="868"/>
        <source>Text hinting:</source>
        <comment>PdfSettingsWidget|</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/pdfmodel.cpp" line="879"/>
        <source>Overprint preview:</source>
        <comment>PdfSettingsWidget|</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/pdfmodel.cpp" line="887"/>
        <source>Solid</source>
        <comment>PdfSettingsWidget|</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/pdfmodel.cpp" line="888"/>
        <source>Shaped</source>
        <comment>PdfSettingsWidget|</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/pdfmodel.cpp" line="891"/>
        <source>Thin line mode:</source>
        <comment>PdfSettingsWidget|</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/pluginhandler.cpp" line="281"/>
        <location filename="../sources/pluginhandler.cpp" line="313"/>
        <location filename="../sources/pluginhandler.cpp" line="346"/>
        <source>Critical</source>
        <comment>PluginHandler|</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/pluginhandler.cpp" line="281"/>
        <source>Could not load PDF plug-in!</source>
        <comment>PluginHandler|</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/pluginhandler.cpp" line="313"/>
        <source>Could not load PS plug-in!</source>
        <comment>PluginHandler|</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/pluginhandler.cpp" line="346"/>
        <source>Could not load DjVu plug-in!</source>
        <comment>PluginHandler|</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/printdialog.cpp" line="61"/>
        <source>Fit to page:</source>
        <comment>PrintDialog|</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/printdialog.cpp" line="65"/>
        <source>Page ranges:</source>
        <comment>PrintDialog|</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/printdialog.cpp" line="68"/>
        <source>All pages</source>
        <comment>PrintDialog|</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/printdialog.cpp" line="69"/>
        <source>Even pages</source>
        <comment>PrintDialog|</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/printdialog.cpp" line="70"/>
        <source>Odd pages</source>
        <comment>PrintDialog|</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/printdialog.cpp" line="73"/>
        <source>Page set:</source>
        <comment>PrintDialog|</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/printdialog.cpp" line="76"/>
        <source>Single page</source>
        <comment>PrintDialog|</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/printdialog.cpp" line="77"/>
        <source>Two pages</source>
        <comment>PrintDialog|</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/printdialog.cpp" line="78"/>
        <source>Four pages</source>
        <comment>PrintDialog|</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/printdialog.cpp" line="79"/>
        <source>Six pages</source>
        <comment>PrintDialog|</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/printdialog.cpp" line="80"/>
        <source>Nine pages</source>
        <comment>PrintDialog|</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/printdialog.cpp" line="81"/>
        <source>Sixteen pages</source>
        <comment>PrintDialog|</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/printdialog.cpp" line="84"/>
        <source>Number-up:</source>
        <comment>PrintDialog|</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/printdialog.cpp" line="87"/>
        <source>Bottom to top and left to right</source>
        <comment>PrintDialog|</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/printdialog.cpp" line="88"/>
        <source>Bottom to top and right to left</source>
        <comment>PrintDialog|</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/printdialog.cpp" line="89"/>
        <source>Left to right and bottom to top</source>
        <comment>PrintDialog|</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/printdialog.cpp" line="90"/>
        <source>Left to right and top to bottom</source>
        <comment>PrintDialog|</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/printdialog.cpp" line="91"/>
        <source>Right to left and bottom to top</source>
        <comment>PrintDialog|</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/printdialog.cpp" line="92"/>
        <source>Right to left and top to bottom</source>
        <comment>PrintDialog|</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/printdialog.cpp" line="93"/>
        <source>Top to bottom and left to right</source>
        <comment>PrintDialog|</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/printdialog.cpp" line="94"/>
        <source>Top to bottom and right to left</source>
        <comment>PrintDialog|</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/printdialog.cpp" line="97"/>
        <source>Number-up layout:</source>
        <comment>PrintDialog|</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/printdialog.cpp" line="99"/>
        <source>Extended options</source>
        <comment>PrintDialog|</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/psmodel.cpp" line="236"/>
        <source>Graphics antialias bits:</source>
        <comment>PsSettingsWidget|</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/psmodel.cpp" line="244"/>
        <source>Text antialias bits:</source>
        <comment>PsSettingsWidget|</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/main.cpp" line="148"/>
        <source>An empty instance name is not allowed.</source>
        <comment>QObject|</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/main.cpp" line="159"/>
        <source>An empty search text is not allowed.</source>
        <comment>QObject|</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/main.cpp" line="187"/>
        <source>Choose instance</source>
        <comment>QObject|</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/main.cpp" line="187"/>
        <source>Instance:</source>
        <comment>QObject|</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/main.cpp" line="216"/>
        <source>Unknown command-line option &apos;%1&apos;.</source>
        <comment>QObject|</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/main.cpp" line="247"/>
        <source>Using &apos;--instance&apos; requires an instance name.</source>
        <comment>QObject|</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/main.cpp" line="253"/>
        <source>Using &apos;--instance&apos; is not allowed without using &apos;--unique&apos;.</source>
        <comment>QObject|</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/main.cpp" line="259"/>
        <source>An instance name must only contain the characters &quot;[A-Z][a-z][0-9]_&quot; and must not begin with a digit.</source>
        <comment>QObject|</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/main.cpp" line="265"/>
        <source>Using &apos;--search&apos; requires a search text.</source>
        <comment>QObject|</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/main.cpp" line="343"/>
        <source>SyncTeX data for &apos;%1&apos; could not be found.</source>
        <comment>QObject|</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/main.cpp" line="440"/>
        <source>Could not prepare signal handler.</source>
        <comment>QObject|</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="784"/>
        <source>Shift</source>
        <comment>QShortcut|</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="785"/>
        <source>Ctrl</source>
        <comment>QShortcut|</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="786"/>
        <source>Alt</source>
        <comment>QShortcut|</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="787"/>
        <source>Shift and Ctrl</source>
        <comment>QShortcut|</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="788"/>
        <source>Shift and Alt</source>
        <comment>QShortcut|</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="789"/>
        <source>Ctrl and Alt</source>
        <comment>QShortcut|</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/recentlyusedmenu.cpp" line="29"/>
        <source>Recently &amp;used</source>
        <comment>RecentlyUsedMenu|</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/recentlyusedmenu.cpp" line="38"/>
        <source>&amp;Clear list</source>
        <comment>RecentlyUsedMenu|</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="66"/>
        <source>General</source>
        <comment>SettingsDialog|</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="117"/>
        <source>&amp;Behavior</source>
        <comment>SettingsDialog|</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="118"/>
        <source>&amp;Graphics</source>
        <comment>SettingsDialog|</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="119"/>
        <source>&amp;Interface</source>
        <comment>SettingsDialog|</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="120"/>
        <source>&amp;Shortcuts</source>
        <comment>SettingsDialog|</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="121"/>
        <source>&amp;Modifiers</source>
        <comment>SettingsDialog|</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="127"/>
        <source>Defaults</source>
        <comment>SettingsDialog|</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="130"/>
        <source>Defaults on current tab</source>
        <comment>SettingsDialog|</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="298"/>
        <source>Open URL:</source>
        <comment>SettingsDialog|</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="305"/>
        <source>Auto-refresh:</source>
        <comment>SettingsDialog|</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="311"/>
        <location filename="../sources/settingsdialog.cpp" line="625"/>
        <location filename="../sources/settingsdialog.cpp" line="633"/>
        <location filename="../sources/settingsdialog.cpp" line="641"/>
        <location filename="../sources/settingsdialog.cpp" line="649"/>
        <source>Effective after restart.</source>
        <comment>SettingsDialog|</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="313"/>
        <source>Track recently used:</source>
        <comment>SettingsDialog|</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="320"/>
        <source>Restore tabs:</source>
        <comment>SettingsDialog|</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="327"/>
        <source>Restore bookmarks:</source>
        <comment>SettingsDialog|</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="334"/>
        <source>Restore per-file settings:</source>
        <comment>SettingsDialog|</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="349"/>
        <source>Synchronize presentation:</source>
        <comment>SettingsDialog|</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="355"/>
        <source>Default</source>
        <comment>SettingsDialog|</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="358"/>
        <source>Presentation screen:</source>
        <comment>SettingsDialog|</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="375"/>
        <source>Highlight color:</source>
        <comment>SettingsDialog|</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="366"/>
        <source>None</source>
        <comment>SettingsDialog|</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="369"/>
        <source>Highlight duration:</source>
        <comment>SettingsDialog|</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="381"/>
        <source>Annotation color:</source>
        <comment>SettingsDialog|</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="387"/>
        <source>&apos;%1&apos; is replaced by the absolute file path. &apos;%2&apos; resp. &apos;%3&apos; is replaced by line resp. column number.</source>
        <comment>SettingsDialog|</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="389"/>
        <source>Source editor:</source>
        <comment>SettingsDialog|</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="421"/>
        <source>Keep obsolete pixmaps:</source>
        <comment>SettingsDialog|</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="430"/>
        <source>Use device pixel ratio:</source>
        <comment>SettingsDialog|</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="439"/>
        <source>Decorate pages:</source>
        <comment>SettingsDialog|</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="446"/>
        <source>Decorate links:</source>
        <comment>SettingsDialog|</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="453"/>
        <source>Decorate form fields:</source>
        <comment>SettingsDialog|</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="459"/>
        <source>Background color:</source>
        <comment>SettingsDialog|</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="465"/>
        <source>Paper color:</source>
        <comment>SettingsDialog|</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="471"/>
        <source>Presentation background color:</source>
        <comment>SettingsDialog|</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="479"/>
        <source>Pages per row:</source>
        <comment>SettingsDialog|</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="489"/>
        <source>Page spacing:</source>
        <comment>SettingsDialog|</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="499"/>
        <source>Thumbnail spacing:</source>
        <comment>SettingsDialog|</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="509"/>
        <source>Thumbnail size:</source>
        <comment>SettingsDialog|</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="514"/>
        <location filename="../sources/settingsdialog.cpp" line="515"/>
        <location filename="../sources/settingsdialog.cpp" line="516"/>
        <location filename="../sources/settingsdialog.cpp" line="517"/>
        <location filename="../sources/settingsdialog.cpp" line="518"/>
        <location filename="../sources/settingsdialog.cpp" line="519"/>
        <location filename="../sources/settingsdialog.cpp" line="520"/>
        <location filename="../sources/settingsdialog.cpp" line="521"/>
        <source>%1 MB</source>
        <comment>SettingsDialog|</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="524"/>
        <source>Cache size:</source>
        <comment>SettingsDialog|</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="531"/>
        <source>Prefetch:</source>
        <comment>SettingsDialog|</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="539"/>
        <source>Prefetch distance:</source>
        <comment>SettingsDialog|</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="595"/>
        <source>Top</source>
        <comment>SettingsDialog|</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="596"/>
        <source>Bottom</source>
        <comment>SettingsDialog|</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="597"/>
        <source>Left</source>
        <comment>SettingsDialog|</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="598"/>
        <source>Right</source>
        <comment>SettingsDialog|</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="601"/>
        <source>Tab position:</source>
        <comment>SettingsDialog|</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="606"/>
        <source>As needed</source>
        <comment>SettingsDialog|</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="607"/>
        <source>Always</source>
        <comment>SettingsDialog|</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="608"/>
        <source>Never</source>
        <comment>SettingsDialog|</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="611"/>
        <source>Tab visibility:</source>
        <comment>SettingsDialog|</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="618"/>
        <source>New tab next to current tab:</source>
        <comment>SettingsDialog|</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="627"/>
        <source>Recently used count:</source>
        <comment>SettingsDialog|</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="635"/>
        <source>File tool bar:</source>
        <comment>SettingsDialog|</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="643"/>
        <source>Edit tool bar:</source>
        <comment>SettingsDialog|</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="651"/>
        <source>View tool bar:</source>
        <comment>SettingsDialog|</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="658"/>
        <source>Current page in window title:</source>
        <comment>SettingsDialog|</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="665"/>
        <source>Instance name in window title:</source>
        <comment>SettingsDialog|</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="672"/>
        <source>Synchronize outline view:</source>
        <comment>SettingsDialog|</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="679"/>
        <source>Highlight current thumbnail:</source>
        <comment>SettingsDialog|</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="686"/>
        <source>Limit thumbnails to results:</source>
        <comment>SettingsDialog|</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="693"/>
        <source>Annotation overlay:</source>
        <comment>SettingsDialog|</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="700"/>
        <source>Form field overlay:</source>
        <comment>SettingsDialog|</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="734"/>
        <source>Zoom:</source>
        <comment>SettingsDialog|</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="740"/>
        <source>Rotate:</source>
        <comment>SettingsDialog|</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="746"/>
        <source>Scroll:</source>
        <comment>SettingsDialog|</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="752"/>
        <source>Copy to clipboard:</source>
        <comment>SettingsDialog|</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="758"/>
        <source>Add annotation:</source>
        <comment>SettingsDialog|</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/shortcuthandler.cpp" line="140"/>
        <source>Action</source>
        <comment>ShortcutHandler|</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/shortcuthandler.cpp" line="143"/>
        <source>Key sequence</source>
        <comment>ShortcutHandler|</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/shortcuthandler.cpp" line="261"/>
        <source>Skip backward</source>
        <comment>ShortcutHandler|</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/shortcuthandler.cpp" line="268"/>
        <source>Skip forward</source>
        <comment>ShortcutHandler|</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/shortcuthandler.cpp" line="275"/>
        <source>Move up</source>
        <comment>ShortcutHandler|</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/shortcuthandler.cpp" line="282"/>
        <source>Move down</source>
        <comment>ShortcutHandler|</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/shortcuthandler.cpp" line="289"/>
        <source>Move left</source>
        <comment>ShortcutHandler|</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/shortcuthandler.cpp" line="296"/>
        <source>Move right</source>
        <comment>ShortcutHandler|</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/miscellaneous.cpp" line="169"/>
        <source>&amp;Expand all</source>
        <comment>TreeView|</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/miscellaneous.cpp" line="170"/>
        <source>&amp;Collapse all</source>
        <comment>TreeView|</comment>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
