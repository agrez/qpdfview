<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="fi_FI">
<context>
    <name>BookmarkMenu</name>
    <message>
        <location filename="../sources/bookmarkmenu.cpp" line="35"/>
        <source>&amp;Open</source>
        <translation type="unfinished">&amp;Avaa</translation>
    </message>
    <message>
        <location filename="../sources/bookmarkmenu.cpp" line="40"/>
        <source>Open in new &amp;tab</source>
        <translation type="unfinished">Avaa uudessa välilehdessä</translation>
    </message>
    <message>
        <location filename="../sources/bookmarkmenu.cpp" line="50"/>
        <source>&amp;Remove bookmark</source>
        <translation type="unfinished">Poista kirjanmerkki</translation>
    </message>
    <message>
        <location filename="../sources/bookmarkmenu.cpp" line="72"/>
        <source>Jump to page %1</source>
        <translation type="unfinished">Siirry sivulle %1</translation>
    </message>
</context>
<context>
    <name>DocumentView</name>
    <message>
        <location filename="../sources/documentview.cpp" line="219"/>
        <source>Supported formats (%1)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/documentview.cpp" line="483"/>
        <location filename="../sources/documentview.cpp" line="523"/>
        <source>Unlock %1</source>
        <translation type="unfinished">Lukitse %1</translation>
    </message>
    <message>
        <location filename="../sources/documentview.cpp" line="483"/>
        <location filename="../sources/documentview.cpp" line="523"/>
        <source>Password:</source>
        <translation type="unfinished">Salasana:</translation>
    </message>
    <message>
        <location filename="../sources/documentview.cpp" line="1471"/>
        <source>Printing &apos;%1&apos;...</source>
        <translation type="unfinished">Tulostetaan tiedostoa &apos;%1&apos;...</translation>
    </message>
    <message>
        <location filename="../sources/documentview.cpp" line="1049"/>
        <source>Information</source>
        <translation type="unfinished">Tiedot</translation>
    </message>
    <message>
        <location filename="../sources/documentview.cpp" line="1049"/>
        <source>Opening URL is disabled in the settings.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/documentview.cpp" line="1101"/>
        <source>Warning</source>
        <translation type="unfinished">Varoitus</translation>
    </message>
    <message>
        <location filename="../sources/documentview.cpp" line="1101"/>
        <source>SyncTeX data for &apos;%1&apos; could not be found.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../sources/mainwindow.cpp" line="175"/>
        <location filename="../sources/mainwindow.cpp" line="267"/>
        <location filename="../sources/mainwindow.cpp" line="831"/>
        <location filename="../sources/mainwindow.cpp" line="848"/>
        <location filename="../sources/mainwindow.cpp" line="868"/>
        <location filename="../sources/mainwindow.cpp" line="904"/>
        <location filename="../sources/mainwindow.cpp" line="1053"/>
        <source>Warning</source>
        <translation type="unfinished">Varoitus</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="175"/>
        <location filename="../sources/mainwindow.cpp" line="267"/>
        <source>Could not open &apos;%1&apos;.</source>
        <translation type="unfinished">Älä avaa kohdetta &apos;%1&apos;.</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="794"/>
        <source>Open</source>
        <translation type="unfinished">Avaa</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="810"/>
        <source>Open in new tab</source>
        <translation type="unfinished">Avaa uudessa välilehdessä</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="831"/>
        <location filename="../sources/mainwindow.cpp" line="1053"/>
        <source>Could not refresh &apos;%1&apos;.</source>
        <translation type="unfinished">Älä päivitä kohdetta &apos;%1&apos;.</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="838"/>
        <source>Save copy</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="848"/>
        <source>Could not save copy at &apos;%1&apos;.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="856"/>
        <source>Save as</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="868"/>
        <source>Could not save as &apos;%1&apos;.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="904"/>
        <source>Could not print &apos;%1&apos;.</source>
        <translation type="unfinished">Älä tulosta kohdetta &apos;%1&apos;.</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="943"/>
        <source>Jump to page</source>
        <translation type="unfinished">Siirry sivulle</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="943"/>
        <source>Page:</source>
        <translation type="unfinished">Sivu:</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1428"/>
        <source>About qpdfview</source>
        <translation type="unfinished">Tietoja qpdfview:istä</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1428"/>
        <source>&lt;p&gt;&lt;b&gt;qpdfview %1&lt;/b&gt;&lt;/p&gt;&lt;p&gt;qpdfview is a tabbed document viewer using Qt.&lt;/p&gt;&lt;p&gt;This version includes:&lt;ul&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1432"/>
        <source>&lt;li&gt;PDF support using Poppler&lt;/li&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1435"/>
        <source>&lt;li&gt;PS support using libspectre&lt;/li&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1438"/>
        <source>&lt;li&gt;DjVu support using DjVuLibre&lt;/li&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1441"/>
        <source>&lt;li&gt;Printing support using CUPS&lt;/li&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1443"/>
        <source>&lt;/ul&gt;&lt;p&gt;See &lt;a href=&quot;https://launchpad.net/qpdfview&quot;&gt;launchpad.net/qpdfview&lt;/a&gt; for more information.&lt;/p&gt;&lt;p&gt;&amp;copy; 2012-2013 The qpdfview developers&lt;/p&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1671"/>
        <source>Page width</source>
        <translation type="unfinished">Sivun leveys</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1672"/>
        <source>Page size</source>
        <translation type="unfinished">Sivun koko</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1702"/>
        <source>Match &amp;case</source>
        <translation type="unfinished">Huomioi &amp;kirjainkoko</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1703"/>
        <source>Highlight &amp;all</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1746"/>
        <source>&amp;Open...</source>
        <translation type="unfinished">&amp;Avaa...</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1747"/>
        <source>Open in new &amp;tab...</source>
        <translation type="unfinished">Avaa uuteen &amp;välilehteen...</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1748"/>
        <source>&amp;Refresh</source>
        <translation type="unfinished">&amp;Päivitä</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1749"/>
        <source>&amp;Save copy...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1750"/>
        <source>Save &amp;as...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1751"/>
        <source>&amp;Print...</source>
        <translation type="unfinished">&amp;Tulosta...</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1752"/>
        <source>E&amp;xit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1756"/>
        <source>&amp;Previous page</source>
        <translation type="unfinished">&amp;Edellinen sivu</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1757"/>
        <source>&amp;Next page</source>
        <translation type="unfinished">&amp;Seuraava sivu</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1758"/>
        <source>&amp;First page</source>
        <translation type="unfinished">&amp;Ensimmäinen sivu</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1759"/>
        <source>&amp;Last page</source>
        <translation type="unfinished">&amp;Viimeinen sivu</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1761"/>
        <source>&amp;Jump to page...</source>
        <translation type="unfinished">&amp;Siirry sivulle...</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1763"/>
        <source>Jump &amp;backward</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1764"/>
        <source>Jump for&amp;ward</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1766"/>
        <source>&amp;Search...</source>
        <translation type="unfinished">&amp;Etsi...</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1767"/>
        <source>Find previous</source>
        <translation type="unfinished">Etsi edellinen</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1768"/>
        <source>Find next</source>
        <translation type="unfinished">Etsi seuraava</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1769"/>
        <source>Cancel search</source>
        <translation type="unfinished">Peruuta haku</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1771"/>
        <source>&amp;Copy to clipboard</source>
        <translation type="unfinished">&amp;Kopioi leikepöydälle</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1772"/>
        <source>&amp;Add annotation</source>
        <translation type="unfinished">%Lisää huomautus</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1774"/>
        <source>Settings...</source>
        <translation type="unfinished">Asetukset...</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1778"/>
        <source>&amp;Continuous</source>
        <translation type="unfinished">&amp;Jatkuva</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1779"/>
        <source>&amp;Two pages</source>
        <translation type="unfinished">&amp;Kaksi sivua</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1780"/>
        <source>Two pages &amp;with cover page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1781"/>
        <source>&amp;Multiple pages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1783"/>
        <source>Zoom &amp;in</source>
        <translation type="unfinished">Zoomaa &amp;lähemmäs</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1784"/>
        <source>Zoom &amp;out</source>
        <translation type="unfinished">Zoomaa &amp;kaiemmas</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1785"/>
        <source>Original &amp;size</source>
        <translation type="unfinished">Alkuperäinen &amp;koko</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1787"/>
        <source>Fit to page width</source>
        <translation type="unfinished">Sovita sivun leveys</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1788"/>
        <source>Fit to page size</source>
        <translation type="unfinished">Sovita sivuun</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1790"/>
        <source>Rotate &amp;left</source>
        <translation type="unfinished">Käännä &amp;vasemmalle</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1791"/>
        <source>Rotate &amp;right</source>
        <translation type="unfinished">Käännä &amp;oikealle</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1793"/>
        <source>Invert colors</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1795"/>
        <source>Fonts...</source>
        <translation type="unfinished">Fontit...</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1797"/>
        <source>&amp;Fullscreen</source>
        <translation type="unfinished">&amp;Koko näyttö</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1798"/>
        <source>&amp;Presentation...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1802"/>
        <source>&amp;Previous tab</source>
        <translation type="unfinished">&amp;Edellinen välilehti</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1803"/>
        <source>&amp;Next tab</source>
        <translation type="unfinished">&amp;Seuraava välilehti</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1805"/>
        <source>&amp;Close tab</source>
        <translation type="unfinished">&amp;Sulje ikkuna</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1806"/>
        <source>Close &amp;all tabs</source>
        <translation type="unfinished">Sulje &amp;kaikki ikkunat</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1807"/>
        <source>Close all tabs &amp;but current tab</source>
        <translation type="unfinished">Sulje kaikki &amp;paitsi valittu välilehti</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1818"/>
        <source>&amp;Previous bookmark</source>
        <translation type="unfinished">&amp;Edellinen kirjanmerkki</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1819"/>
        <source>&amp;Next bookmark</source>
        <translation type="unfinished">&amp;Seuraava kirjanmerkki</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1821"/>
        <source>&amp;Add bookmark</source>
        <translation type="unfinished">&amp;Lisää kirjanmerkki</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1822"/>
        <source>&amp;Remove bookmark</source>
        <translation type="unfinished">&amp;Poista kirjanmerkki</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1823"/>
        <source>Remove all bookmarks</source>
        <translation type="unfinished">Poista kaikki kirjanmerkit</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1827"/>
        <source>&amp;Contents</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1828"/>
        <source>&amp;About</source>
        <translation type="unfinished">&amp;Tietoja</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1862"/>
        <location filename="../sources/mainwindow.cpp" line="1956"/>
        <source>&amp;File</source>
        <translation type="unfinished">&amp;Tiedosto</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1865"/>
        <location filename="../sources/mainwindow.cpp" line="1991"/>
        <source>&amp;Edit</source>
        <translation type="unfinished">&amp;Muokkaa</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1868"/>
        <location filename="../sources/mainwindow.cpp" line="2004"/>
        <source>&amp;View</source>
        <translation type="unfinished">&amp;Näytä</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1873"/>
        <source>&amp;Search</source>
        <translation type="unfinished">&amp;Etsi</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1921"/>
        <source>&amp;Outline</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1933"/>
        <source>&amp;Properties</source>
        <translation type="unfinished">&amp;Ominaisuudet</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1943"/>
        <source>&amp;Thumbnails</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="2014"/>
        <source>&amp;Tool bars</source>
        <translation type="unfinished">&amp;Työkalupalkit</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="2017"/>
        <source>&amp;Docks</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="2026"/>
        <source>&amp;Tabs</source>
        <translation type="unfinished">&amp;Välilehdet</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="2034"/>
        <source>&amp;Bookmarks</source>
        <translation type="unfinished">&amp;Kirjanmerkit</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="2042"/>
        <source>&amp;Help</source>
        <translation type="unfinished">&amp;Ohje</translation>
    </message>
</context>
<context>
    <name>Model::PdfDocument</name>
    <message>
        <location filename="../sources/pdfmodel.cpp" line="769"/>
        <source>Name</source>
        <translation type="unfinished">Nimi</translation>
    </message>
    <message>
        <location filename="../sources/pdfmodel.cpp" line="769"/>
        <source>Type</source>
        <translation type="unfinished">Tyyppi</translation>
    </message>
    <message>
        <location filename="../sources/pdfmodel.cpp" line="769"/>
        <source>Embedded</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/pdfmodel.cpp" line="769"/>
        <source>Subset</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/pdfmodel.cpp" line="769"/>
        <source>File</source>
        <translation type="unfinished">Tiedosto</translation>
    </message>
    <message>
        <location filename="../sources/pdfmodel.cpp" line="777"/>
        <location filename="../sources/pdfmodel.cpp" line="778"/>
        <source>Yes</source>
        <translation type="unfinished">Kyllä</translation>
    </message>
    <message>
        <location filename="../sources/pdfmodel.cpp" line="777"/>
        <location filename="../sources/pdfmodel.cpp" line="778"/>
        <source>No</source>
        <translation type="unfinished">Ei</translation>
    </message>
</context>
<context>
    <name>Model::PdfPage</name>
    <message>
        <location filename="../sources/pdfmodel.cpp" line="362"/>
        <source>Information</source>
        <translation type="unfinished">Tiedot</translation>
    </message>
    <message>
        <location filename="../sources/pdfmodel.cpp" line="362"/>
        <source>Version 0.20.1 or higher of the Poppler library is required to add or remove annotations.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Model::PsDocument</name>
    <message>
        <location filename="../sources/psmodel.cpp" line="217"/>
        <source>Title</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/psmodel.cpp" line="218"/>
        <source>Created for</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/psmodel.cpp" line="219"/>
        <source>Creator</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/psmodel.cpp" line="220"/>
        <source>Creation date</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/psmodel.cpp" line="221"/>
        <source>Format</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/psmodel.cpp" line="222"/>
        <source>Language level</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PageItem</name>
    <message>
        <location filename="../sources/pageitem.cpp" line="458"/>
        <source>Go to page %1.</source>
        <translation type="unfinished">Siirry sivulle %1</translation>
    </message>
    <message>
        <location filename="../sources/pageitem.cpp" line="462"/>
        <source>Go to page %1 of file &apos;%2&apos;.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/pageitem.cpp" line="470"/>
        <source>Open &apos;%1&apos;.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/pageitem.cpp" line="505"/>
        <source>Edit form field &apos;%1&apos;.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/pageitem.cpp" line="721"/>
        <source>Copy &amp;text</source>
        <translation type="unfinished">Kopioi &amp;teksti</translation>
    </message>
    <message>
        <location filename="../sources/pageitem.cpp" line="722"/>
        <source>Copy &amp;image</source>
        <translation type="unfinished">Kopioi &amp;kuva</translation>
    </message>
    <message>
        <location filename="../sources/pageitem.cpp" line="723"/>
        <source>Save image to &amp;file...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/pageitem.cpp" line="749"/>
        <source>Save image to file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/pageitem.cpp" line="753"/>
        <source>Warning</source>
        <translation type="unfinished">Varoitus</translation>
    </message>
    <message>
        <location filename="../sources/pageitem.cpp" line="753"/>
        <source>Could not save image to file &apos;%1&apos;.</source>
        <translation type="unfinished">Tiedostoa &apos;%1&apos; ei voitu tallentaa.</translation>
    </message>
    <message>
        <location filename="../sources/pageitem.cpp" line="766"/>
        <source>Add &amp;text</source>
        <translation type="unfinished">Lisää &amp;teksti</translation>
    </message>
    <message>
        <location filename="../sources/pageitem.cpp" line="767"/>
        <source>Add &amp;highlight</source>
        <translation type="unfinished">Lisää &amp;korostus</translation>
    </message>
    <message>
        <location filename="../sources/pageitem.cpp" line="804"/>
        <source>&amp;Remove annotation</source>
        <translation type="unfinished">&amp;Poista huomautus</translation>
    </message>
</context>
<context>
    <name>PdfSettingsWidget</name>
    <message>
        <location filename="../sources/pdfmodel.cpp" line="793"/>
        <source>Antialiasing:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/pdfmodel.cpp" line="800"/>
        <source>Text antialiasing:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/pdfmodel.cpp" line="807"/>
        <location filename="../sources/pdfmodel.cpp" line="837"/>
        <source>None</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/pdfmodel.cpp" line="808"/>
        <source>Full</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/pdfmodel.cpp" line="809"/>
        <source>Reduced</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/pdfmodel.cpp" line="812"/>
        <location filename="../sources/pdfmodel.cpp" line="819"/>
        <source>Text hinting:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/pdfmodel.cpp" line="830"/>
        <source>Overprint preview:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/pdfmodel.cpp" line="838"/>
        <source>Solid</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/pdfmodel.cpp" line="839"/>
        <source>Shaped</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/pdfmodel.cpp" line="842"/>
        <source>Thin line mode:</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PluginHandler</name>
    <message>
        <location filename="../sources/pluginhandler.cpp" line="275"/>
        <location filename="../sources/pluginhandler.cpp" line="307"/>
        <location filename="../sources/pluginhandler.cpp" line="340"/>
        <source>Critical</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/pluginhandler.cpp" line="275"/>
        <source>Could not load PDF plug-in!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/pluginhandler.cpp" line="307"/>
        <source>Could not load PS plug-in!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/pluginhandler.cpp" line="340"/>
        <source>Could not load DjVu plug-in!</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PrintDialog</name>
    <message>
        <location filename="../sources/printdialog.cpp" line="61"/>
        <source>Fit to page:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/printdialog.cpp" line="65"/>
        <source>Page ranges:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/printdialog.cpp" line="68"/>
        <source>All pages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/printdialog.cpp" line="69"/>
        <source>Even pages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/printdialog.cpp" line="70"/>
        <source>Odd pages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/printdialog.cpp" line="73"/>
        <source>Page set:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/printdialog.cpp" line="76"/>
        <source>Single page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/printdialog.cpp" line="77"/>
        <source>Two pages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/printdialog.cpp" line="78"/>
        <source>Four pages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/printdialog.cpp" line="79"/>
        <source>Six pages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/printdialog.cpp" line="80"/>
        <source>Nine pages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/printdialog.cpp" line="81"/>
        <source>Sixteen pages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/printdialog.cpp" line="84"/>
        <source>Number-up:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/printdialog.cpp" line="87"/>
        <source>Bottom to top and left to right</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/printdialog.cpp" line="88"/>
        <source>Bottom to top and right to left</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/printdialog.cpp" line="89"/>
        <source>Left to right and bottom to top</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/printdialog.cpp" line="90"/>
        <source>Left to right and top to bottom</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/printdialog.cpp" line="91"/>
        <source>Right to left and bottom to top</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/printdialog.cpp" line="92"/>
        <source>Right to left and top to bottom</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/printdialog.cpp" line="93"/>
        <source>Top to bottom and left to right</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/printdialog.cpp" line="94"/>
        <source>Top to bottom and right to left</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/printdialog.cpp" line="97"/>
        <source>Number-up layout:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/printdialog.cpp" line="99"/>
        <source>Extended options</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PsSettingsWidget</name>
    <message>
        <location filename="../sources/psmodel.cpp" line="236"/>
        <source>Graphics antialias bits:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/psmodel.cpp" line="244"/>
        <source>Text antialias bits:</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../sources/main.cpp" line="127"/>
        <source>An empty instance name is not allowed.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/main.cpp" line="138"/>
        <source>An empty search text is not allowed.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/main.cpp" line="203"/>
        <source>Using &apos;--instance&apos; requires an instance name.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/main.cpp" line="209"/>
        <source>Using &apos;--instance&apos; is not allowed without using &apos;--unique&apos;.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/main.cpp" line="215"/>
        <source>Using &apos;--search&apos; requires a search text.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/main.cpp" line="258"/>
        <source>SyncTeX data for &apos;%1&apos; could not be found.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/main.cpp" line="353"/>
        <source>Could not prepare signal handler.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QShortcut</name>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="650"/>
        <source>Shift</source>
        <translation type="unfinished">Shift</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="651"/>
        <source>Ctrl</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="652"/>
        <source>Alt</source>
        <translation type="unfinished">Alt</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="653"/>
        <source>Shift and Ctrl</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="654"/>
        <source>Shift and Alt</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="655"/>
        <source>Ctrl and Alt</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>RecentlyUsedMenu</name>
    <message>
        <location filename="../sources/recentlyusedmenu.cpp" line="28"/>
        <source>Recently &amp;used</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/recentlyusedmenu.cpp" line="37"/>
        <source>&amp;Clear list</source>
        <translation type="unfinished">&amp;Tyhjennä lista</translation>
    </message>
</context>
<context>
    <name>SettingsDialog</name>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="105"/>
        <source>&amp;Behavior</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="106"/>
        <source>&amp;Graphics</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="107"/>
        <source>&amp;Interface</source>
        <translation type="unfinished">&amp;Käyttöliittymä</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="108"/>
        <source>&amp;Shortcuts</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="109"/>
        <source>&amp;Modifiers</source>
        <translation type="unfinished">&amp;Muokkaajat</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="115"/>
        <source>Defaults</source>
        <translation type="unfinished">Oletusasetukset</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="324"/>
        <source>Open URL:</source>
        <translation type="unfinished">Avaa URL-osoite:</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="331"/>
        <source>Auto-refresh:</source>
        <translation type="unfinished">Automaattinen päivitys:</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="337"/>
        <location filename="../sources/settingsdialog.cpp" line="572"/>
        <location filename="../sources/settingsdialog.cpp" line="580"/>
        <location filename="../sources/settingsdialog.cpp" line="588"/>
        <source>Effective after restart.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="339"/>
        <source>Track recently used:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="346"/>
        <source>Restore tabs:</source>
        <translation type="unfinished">Palauta välilehdet</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="353"/>
        <source>Restore bookmarks:</source>
        <translation type="unfinished">Palauta kirjanmerkit</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="360"/>
        <source>Restore per-file settings:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="375"/>
        <source>Synchronize presentation:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="381"/>
        <source>Default</source>
        <translation type="unfinished">Palauta oletusarvot</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="384"/>
        <source>Presentation screen:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="415"/>
        <source>Annotation color:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="421"/>
        <source>&apos;%1&apos; is replaced by the absolute file path. &apos;%2&apos; resp. &apos;%3&apos; is replaced by line resp. column number.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="423"/>
        <source>Source editor:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="433"/>
        <source>Decorate pages:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="440"/>
        <source>Decorate links:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="447"/>
        <source>Decorate form fields:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="402"/>
        <source>None</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="405"/>
        <source>Highlight duration:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="457"/>
        <source>Background color:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="467"/>
        <source>Paper color:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="475"/>
        <source>Pages per row:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="485"/>
        <source>Page spacing:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="495"/>
        <source>Thumbnail spacing:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="505"/>
        <source>Thumbnail size:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="604"/>
        <source>Highlight current thumbnail:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="611"/>
        <source>Limit thumbnails to results:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="54"/>
        <source>General</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="394"/>
        <source>Highlight color:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="510"/>
        <location filename="../sources/settingsdialog.cpp" line="511"/>
        <location filename="../sources/settingsdialog.cpp" line="512"/>
        <location filename="../sources/settingsdialog.cpp" line="513"/>
        <location filename="../sources/settingsdialog.cpp" line="514"/>
        <location filename="../sources/settingsdialog.cpp" line="515"/>
        <location filename="../sources/settingsdialog.cpp" line="516"/>
        <location filename="../sources/settingsdialog.cpp" line="517"/>
        <source>%1 MB</source>
        <translation type="unfinished">%1 MB</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="520"/>
        <source>Cache size:</source>
        <translation type="unfinished">Välimuistin koko:</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="527"/>
        <source>Prefetch:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="535"/>
        <source>Prefetch distance:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="543"/>
        <source>Top</source>
        <translation type="unfinished">Ylös</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="544"/>
        <source>Bottom</source>
        <translation type="unfinished">Alas</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="545"/>
        <source>Left</source>
        <translation type="unfinished">Vasen</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="546"/>
        <source>Right</source>
        <translation type="unfinished">Oikea</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="549"/>
        <source>Tab position:</source>
        <translation type="unfinished">Välilehtien sijainti:</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="554"/>
        <source>As needed</source>
        <translation type="unfinished">Tarvittaessa</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="555"/>
        <source>Always</source>
        <translation type="unfinished">Aina</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="556"/>
        <source>Never</source>
        <translation type="unfinished">Ei koskaan</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="559"/>
        <source>Tab visibility:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="566"/>
        <source>New tab next to current tab:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="597"/>
        <source>Current page in window title:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="574"/>
        <source>File tool bar:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="582"/>
        <source>Edit tool bar:</source>
        <translation type="unfinished">Muokkaa työkaluriviä:</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="590"/>
        <source>View tool bar:</source>
        <translation type="unfinished">Näytä työkalurivi:</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="620"/>
        <source>Zoom:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="626"/>
        <source>Rotate:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="632"/>
        <source>Scroll:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="638"/>
        <source>Copy to clipboard:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="644"/>
        <source>Add annotation:</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ShortcutHandler</name>
    <message>
        <location filename="../sources/shortcuthandler.cpp" line="261"/>
        <source>Skip backward</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/shortcuthandler.cpp" line="268"/>
        <source>Skip forward</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/shortcuthandler.cpp" line="275"/>
        <source>Move up</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/shortcuthandler.cpp" line="282"/>
        <source>Move down</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/shortcuthandler.cpp" line="289"/>
        <source>Move left</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/shortcuthandler.cpp" line="296"/>
        <source>Move right</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/shortcuthandler.cpp" line="140"/>
        <source>Action</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/shortcuthandler.cpp" line="143"/>
        <source>Key sequence</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>TreeView</name>
    <message>
        <location filename="../sources/miscellaneous.cpp" line="153"/>
        <source>&amp;Expand all</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/miscellaneous.cpp" line="154"/>
        <source>&amp;Collapse all</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
